import { useEffect, useState } from "react";

function App() {
  const [scrolled, setScrolled] = useState(false);
  const [dark, setDark] = useState(true);
  const [mobileOpen, setMobileOpen] = useState(false);
  const [formStatus, setFormStatus] = useState<"idle" | "sending" | "sent">("idle");

  useEffect(() => {
    const isDark = document.documentElement.classList.contains("dark");
    setDark(isDark);

    const onScroll = () => setScrolled(window.scrollY > 20);
    window.addEventListener("scroll", onScroll, { passive: true });
    return () => window.removeEventListener("scroll", onScroll);
  }, []);

  const toggleTheme = () => {
    const next = !dark;
    setDark(next);
    document.documentElement.classList.toggle("dark", next);
    localStorage.setItem("portfolio-theme", next ? "dark" : "light");
  };

  const handleSubmit = (e: React.FormEvent) => {
    e.preventDefault();
    setFormStatus("sending");
    setTimeout(() => setFormStatus("sent"), 900);
  };

  const navLinks = [
    { href: "#about", label: "About" },
    { href: "#skills", label: "Skills" },
    { href: "#projects", label: "Projects" },
    { href: "#experience", label: "Experience" },
    { href: "#contact", label: "Contact" },
  ];

  return (
    <>
      {/* Navbar */}
      <header className={`navbar ${scrolled ? "scrolled" : ""}`}>
        <div className="container nav-inner">
          <a href="#" className="logo">
            <span className="logo-mark">AR</span>
            Alex Rivera
          </a>

          <nav className="nav-links">
            {navLinks.map((l) => (
              <a key={l.href} href={l.href}>
                {l.label}
              </a>
            ))}
          </nav>

          <div className="nav-actions">
            <button
              className="theme-toggle"
              onClick={toggleTheme}
              aria-label="Toggle theme"
            >
              {dark ? (
                <svg width="18" height="18" viewBox="0 0 24 24" fill="none" stroke="currentColor" strokeWidth="2">
                  <circle cx="12" cy="12" r="5" />
                  <path d="M12 1v2M12 21v2M4.22 4.22l1.42 1.42M18.36 18.36l1.42 1.42M1 12h2M21 12h2M4.22 19.78l1.42-1.42M18.36 5.64l1.42-1.42" />
                </svg>
              ) : (
                <svg width="18" height="18" viewBox="0 0 24 24" fill="none" stroke="currentColor" strokeWidth="2">
                  <path d="M21 12.79A9 9 0 1 1 11.21 3 7 7 0 0 0 21 12.79z" />
                </svg>
              )}
            </button>
            <a href="#contact" className="btn btn-primary">
              Hire me
            </a>
            <button
              className="mobile-menu-btn"
              onClick={() => setMobileOpen(!mobileOpen)}
              aria-label="Menu"
            >
              <svg width="22" height="22" viewBox="0 0 24 24" fill="none" stroke="currentColor" strokeWidth="2">
                {mobileOpen ? (
                  <path d="M18 6L6 18M6 6l12 12" />
                ) : (
                  <path d="M3 12h18M3 6h18M3 18h18" />
                )}
              </svg>
            </button>
          </div>
        </div>
      </header>

      {/* Mobile nav */}
      <div className={`mobile-nav ${mobileOpen ? "open" : ""}`}>
        {navLinks.map((l) => (
          <a key={l.href} href={l.href} onClick={() => setMobileOpen(false)}>
            {l.label}
          </a>
        ))}
        <a href="#contact" className="btn btn-primary" style={{ marginTop: 16 }} onClick={() => setMobileOpen(false)}>
          Hire me
        </a>
      </div>

      {/* Hero */}
      <section className="hero">
        <div className="container">
          <div className="hero-content">
            <div className="hero-badge">
              <span className="dot" />
              Available for new projects
            </div>
            <h1>
              I craft fast, accessible{" "}
              <span className="gradient">digital experiences</span> that feel inevitable.
            </h1>
            <p className="hero-sub">
              Full-Stack Developer & AI Engineer building high-performance web apps,
              mobile products, and intelligent systems that people actually love to use.
            </p>
            <div className="hero-cta">
              <a href="#projects" className="btn btn-primary">
                View my work
                <svg width="16" height="16" viewBox="0 0 24 24" fill="none" stroke="currentColor" strokeWidth="2.5">
                  <path d="M5 12h14M12 5l7 7-7 7" />
                </svg>
              </a>
              <a href="#contact" className="btn btn-outline">
                Get in touch
              </a>
            </div>
            <div className="hero-stats">
              <div className="stat">
                <span className="stat-value">6+</span>
                <span className="stat-label">Years experience</span>
              </div>
              <div className="stat">
                <span className="stat-value">40+</span>
                <span className="stat-label">Projects shipped</span>
              </div>
              <div className="stat">
                <span className="stat-value">12</span>
                <span className="stat-label">Happy clients</span>
              </div>
            </div>
          </div>
        </div>
      </section>

      {/* About */}
      <section className="section" id="about">
        <div className="container">
          <p className="section-label">About</p>
          <h2 className="section-title">Building products that matter</h2>
          <div className="about-grid">
            <div className="about-text">
              <p>
                I'm Alex Rivera — a full-stack developer and AI engineer based in the
                intersection of design, engineering, and intelligence. I specialize in
                creating high-performance web applications, polished mobile experiences,
                and production-grade AI systems.
              </p>
              <p>
                My work sits at the sweet spot between elegant interfaces and robust
                architecture. Whether it's a real-time collaborative tool, an AI-powered
                product, or a complex data platform, I focus on making technology feel
                inevitable — fast, accessible, and a joy to use.
              </p>
              <p>
                Previously I've shipped products used by tens of thousands of people and
                partnered with startups and established teams to turn ambitious ideas
                into reliable software.
              </p>
            </div>
            <div className="about-card">
              <h3>What I bring</h3>
              <ul className="about-list">
                <li>
                  <span className="icon">⚡</span>
                  <span>End-to-end ownership — from product thinking to production</span>
                </li>
                <li>
                  <span className="icon">🎯</span>
                  <span>Obsessive focus on performance, accessibility & UX polish</span>
                </li>
                <li>
                  <span className="icon">🤖</span>
                  <span>Practical AI integration that ships (not just demos)</span>
                </li>
                <li>
                  <span className="icon">📐</span>
                  <span>Clean architecture that scales with the product</span>
                </li>
              </ul>
            </div>
          </div>
        </div>
      </section>

      {/* Skills */}
      <section className="section" id="skills">
        <div className="container">
          <p className="section-label">Skills</p>
          <h2 className="section-title">Tools & expertise</h2>
          <p className="section-desc">
            A focused stack chosen for speed, reliability, and developer experience.
          </p>
          <div className="skills-grid">
            <div className="skill-card">
              <h3>Frontend</h3>
              <p>Building responsive, accessible interfaces that feel native.</p>
              <div className="tags">
                <span className="tag">React</span>
                <span className="tag">TypeScript</span>
                <span className="tag">Next.js</span>
                <span className="tag">Vite</span>
                <span className="tag">Tailwind</span>
                <span className="tag">Framer Motion</span>
              </div>
            </div>
            <div className="skill-card">
              <h3>Backend</h3>
              <p>APIs, services, and infrastructure that stay out of the way.</p>
              <div className="tags">
                <span className="tag">Node.js</span>
                <span className="tag">Python</span>
                <span className="tag">PostgreSQL</span>
                <span className="tag">Redis</span>
                <span className="tag">GraphQL</span>
                <span className="tag">tRPC</span>
              </div>
            </div>
            <div className="skill-card">
              <h3>AI & ML</h3>
              <p>Shipping intelligent features that users actually trust.</p>
              <div className="tags">
                <span className="tag">LLMs</span>
                <span className="tag">LangChain</span>
                <span className="tag">RAG</span>
                <span className="tag">OpenAI</span>
                <span className="tag">Hugging Face</span>
                <span className="tag">Vector DBs</span>
              </div>
            </div>
            <div className="skill-card">
              <h3>Mobile & Product</h3>
              <p>Cross-platform apps and product systems that scale.</p>
              <div className="tags">
                <span className="tag">React Native</span>
                <span className="tag">Expo</span>
                <span className="tag">Flutter</span>
                <span className="tag">Figma</span>
                <span className="tag">Product Design</span>
              </div>
            </div>
          </div>
        </div>
      </section>

      {/* Projects */}
      <section className="section" id="projects">
        <div className="container">
          <p className="section-label">Selected work</p>
          <h2 className="section-title">Projects I'm proud of</h2>
          <p className="section-desc">
            A selection of recent work spanning web platforms, mobile apps, and AI products.
          </p>
          <div className="projects-grid">
            <article className="project-card">
              <div className="project-image">
                <div className="placeholder">Nexus</div>
              </div>
              <div className="project-body">
                <h3>Nexus — AI Research Workspace</h3>
                <p>
                  Collaborative research platform with RAG-powered knowledge base,
                  real-time co-editing, and intelligent document synthesis. Used by
                  research teams across three continents.
                </p>
                <div className="tags" style={{ marginBottom: 16 }}>
                  <span className="tag">Next.js</span>
                  <span className="tag">LangChain</span>
                  <span className="tag">PostgreSQL</span>
                  <span className="tag">WebSockets</span>
                </div>
                <div className="project-links">
                  <a href="#">Live demo →</a>
                  <a href="#">Case study →</a>
                </div>
              </div>
            </article>

            <article className="project-card">
              <div className="project-image">
                <div className="placeholder">Pulse</div>
              </div>
              <div className="project-body">
                <h3>Pulse — Real-time Analytics</h3>
                <p>
                  High-performance analytics dashboard processing millions of events
                  per day. Sub-100ms query latency with custom aggregation pipelines
                  and beautiful, dense visualizations.
                </p>
                <div className="tags" style={{ marginBottom: 16 }}>
                  <span className="tag">React</span>
                  <span className="tag">ClickHouse</span>
                  <span className="tag">Go</span>
                  <span className="tag">D3</span>
                </div>
                <div className="project-links">
                  <a href="#">Live demo →</a>
                  <a href="#">GitHub →</a>
                </div>
              </div>
            </article>

            <article className="project-card">
              <div className="project-image">
                <div className="placeholder">Forge</div>
              </div>
              <div className="project-body">
                <h3>Forge — Mobile Design System</h3>
                <p>
                  Cross-platform design system and component library powering three
                  production apps. Includes accessibility tooling, theme engine, and
                  automated visual regression testing.
                </p>
                <div className="tags" style={{ marginBottom: 16 }}>
                  <span className="tag">React Native</span>
                  <span className="tag">Expo</span>
                  <span className="tag">Storybook</span>
                  <span className="tag">TypeScript</span>
                </div>
                <div className="project-links">
                  <a href="#">Docs →</a>
                  <a href="#">GitHub →</a>
                </div>
              </div>
            </article>
          </div>
        </div>
      </section>

      {/* Experience */}
      <section className="section" id="experience">
        <div className="container">
          <p className="section-label">Experience</p>
          <h2 className="section-title">Where I've worked</h2>
          <div className="timeline">
            <div className="timeline-item">
              <span className="timeline-dot" />
              <h3>Senior Full-Stack & AI Engineer</h3>
              <p className="timeline-meta">Lumina Labs · 2023 — Present</p>
              <p>
                Leading development of AI-powered products. Architected the core
                RAG pipeline and real-time collaboration layer that powers the flagship
                platform. Mentoring engineers and shaping technical strategy.
              </p>
            </div>
            <div className="timeline-item">
              <span className="timeline-dot" />
              <h3>Full-Stack Developer</h3>
              <p className="timeline-meta">Vertex Systems · 2020 — 2023</p>
              <p>
                Built and scaled customer-facing web applications serving 50k+ MAU.
                Owned the frontend platform, introduced TypeScript and modern React
                patterns, and improved core web vitals by 40%.
              </p>
            </div>
            <div className="timeline-item">
              <span className="timeline-dot" />
              <h3>Software Engineer</h3>
              <p className="timeline-meta">Studio North · 2018 — 2020</p>
              <p>
                Developed mobile and web products for early-stage startups. Worked
                closely with designers and founders to ship MVPs and iterate rapidly
                based on user feedback.
              </p>
            </div>
          </div>
        </div>
      </section>

      {/* Contact */}
      <section className="section" id="contact">
        <div className="container">
          <p className="section-label">Contact</p>
          <h2 className="section-title">Let's build something great</h2>
          <div className="contact-wrapper">
            <div className="contact-info">
              <h3>Open to opportunities</h3>
              <p>
                Whether you have a product idea, need help scaling an existing
                system, or just want to talk shop — I'd love to hear from you.
              </p>
              <div className="contact-links">
                <a href="mailto:alex@rivera.dev" className="contact-link">
                  <span className="icon">✉</span>
                  alex@rivera.dev
                </a>
                <a href="https://github.com" className="contact-link" target="_blank" rel="noreferrer">
                  <span className="icon">⌥</span>
                  github.com/alexrivera
                </a>
                <a href="https://linkedin.com" className="contact-link" target="_blank" rel="noreferrer">
                  <span className="icon">in</span>
                  linkedin.com/in/alexrivera
                </a>
              </div>
            </div>

            <form className="contact-form" onSubmit={handleSubmit}>
              <div className="form-group">
                <label htmlFor="name">Name</label>
                <input id="name" name="name" type="text" required placeholder="Your name" />
              </div>
              <div className="form-group">
                <label htmlFor="email">Email</label>
                <input id="email" name="email" type="email" required placeholder="you@company.com" />
              </div>
              <div className="form-group">
                <label htmlFor="message">Message</label>
                <textarea id="message" name="message" required placeholder="Tell me about your project..." />
              </div>
              <button type="submit" className="btn btn-primary" disabled={formStatus !== "idle"}>
                {formStatus === "idle" && "Send message"}
                {formStatus === "sending" && "Sending..."}
                {formStatus === "sent" && "Message sent ✓"}
              </button>
            </form>
          </div>
        </div>
      </section>

      {/* Footer */}
      <footer className="footer">
        <div className="container footer-inner">
          <p>© {new Date().getFullYear()} Alex Rivera. Crafted with care.</p>
          <div className="footer-links">
            <a href="#about">About</a>
            <a href="#projects">Projects</a>
            <a href="#contact">Contact</a>
          </div>
        </div>
      </footer>
    </>
  );
}

export default App;
